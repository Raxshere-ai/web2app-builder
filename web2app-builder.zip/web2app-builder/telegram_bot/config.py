import os
import logging
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Telegram Configuration
BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN tidak boleh kosong!")

# Admin IDs - Fix parsing
ADMIN_IDS = []
admin_ids_str = os.getenv("ADMIN_IDS", "")
if admin_ids_str:
    for id_str in admin_ids_str.split(","):
        id_str = id_str.strip()
        if id_str.isdigit():
            ADMIN_IDS.append(int(id_str))
if not ADMIN_IDS:
    ADMIN_IDS = [123456789]  # Default admin

# Build Settings
MAX_BUILD_TIME = int(os.getenv("MAX_BUILD_TIME", 1800))
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", 50)) * 1024 * 1024  # Convert to bytes
BUILD_OUTPUT_DIR = os.getenv("BUILD_OUTPUT_DIR", "/tmp/web2app_builds")

# Docker Images
DOCKER_IMAGE_ANDROID = os.getenv("DOCKER_IMAGE_ANDROID", "flutter-android-builder:latest")
DOCKER_IMAGE_WEB = os.getenv("DOCKER_IMAGE_WEB", "flutter-web-builder:latest")

# Paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEYSTORE_DIR = os.path.join(BASE_DIR, "keystores")
ENV_DIR = os.path.join(BASE_DIR, "env")
LOG_DIR = os.path.join(BASE_DIR, "logs")

# Create directories
for dir_path in [BUILD_OUTPUT_DIR, KEYSTORE_DIR, ENV_DIR, LOG_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# Logging
LOG_LEVEL = logging.INFO