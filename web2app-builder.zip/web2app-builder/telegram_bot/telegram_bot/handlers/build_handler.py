import os
import subprocess
import tempfile
import shutil
import time
import json
import threading
from typing import Optional, Tuple, Dict, Any
from git import Repo
from git.exc import GitCommandError

class BuildHandler:
    def __init__(self, bot, logger):
        self.bot = bot
        self.logger = logger
        self.active_builds = {}
        self.build_stats = self._load_stats()
    
    def _load_stats(self) -> Dict[str, Any]:
        """Load build statistics from file"""
        stats_file = "/tmp/build_stats.json"
        if os.path.exists(stats_file):
            try:
                with open(stats_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        
        return {
            "total_builds": 0,
            "success": 0,
            "failed": 0,
            "pending": 0,
            "android": 0,
            "web": 0,
            "native": 0,
            "last_build": "Never"
        }
    
    def _save_stats(self):
        """Save build statistics"""
        stats_file = "/tmp/build_stats.json"
        try:
            with open(stats_file, 'w') as f:
                json.dump(self.build_stats, f)
        except:
            pass
    
    def start_build(self, chat_id: int, user_id: int, build_type: str, repo_url: str, message_id: int = None) -> Tuple[bool, str]:
        """Start build process in background thread"""
        
        # Update stats
        self.build_stats["total_builds"] += 1
        self.build_stats["pending"] += 1
        if build_type in self.build_stats:
            self.build_stats[build_type] += 1
        self._save_stats()
        
        # Start build in thread
        thread = threading.Thread(
            target=self._build_thread,
            args=(chat_id, user_id, build_type, repo_url, message_id)
        )
        thread.daemon = True
        thread.start()
        
        return True, "Build started"
    
    def _build_thread(self, chat_id: int, user_id: int, build_type: str, repo_url: str, message_id: int):
        """Actual build process running in thread"""
        build_dir = None
        result_file = None
        
        try:
            # Create temp directory
            build_id = f"build_{user_id}_{int(time.time())}"
            build_dir = tempfile.mkdtemp(prefix=f"web2app_{build_id}_")
            
            # Update status
            self._update_message(chat_id, message_id, f"📦 Cloning repository...\n`{repo_url}`")
            
            # Clone repository
            try:
                repo = Repo.clone_from(repo_url, build_dir, depth=1)
                self.logger.info(f"Repository cloned: {repo_url}")
            except GitCommandError as e:
                raise Exception(f"Gagal clone repository: {str(e)}")
            
            # Check project type
            is_flutter = os.path.exists(os.path.join(build_dir, "pubspec.yaml"))
            is_android = os.path.exists(os.path.join(build_dir, "app", "build.gradle")) or \
                        os.path.exists(os.path.join(build_dir, "app", "build.gradle.kts"))
            
            self._update_message(chat_id, message_id, f"🔨 Building {build_type}...\nIni bisa makan waktu 5-15 menit.")
            
            # Build based on type
            if build_type == "android":
                if is_flutter:
                    result_file = self._build_flutter_android(build_dir, build_id, user_id)
                elif is_android:
                    result_file = self._build_native_android(build_dir, build_id, user_id)
                else:
                    raise Exception("Bukan project Flutter atau Android yang valid!")
            
            elif build_type == "web":
                if is_flutter:
                    result_file = self._build_flutter_web(build_dir, build_id, user_id)
                else:
                    raise Exception("Bukan project Flutter Web!")
            
            elif build_type == "native":
                if is_android:
                    result_file = self._build_native_android(build_dir, build_id, user_id)
                else:
                    raise Exception("Bukan project Android Native!")
            
            else:
                raise Exception(f"Tipe build tidak dikenal: {build_type}")
            
            # Sign APK if available
            if result_file and result_file.endswith('.apk'):
                keystore_path = f"/app/keystores/user_{user_id}.jks"
                env_file = f"/app/env/user_{user_id}.env"
                
                if os.path.exists(keystore_path) and os.path.exists(env_file):
                    self._update_message(chat_id, message_id, "🔏 Signing APK dengan keystore...")
                    signed_file = self._sign_apk(result_file, keystore_path, env_file)
                    if signed_file:
                        os.remove(result_file)
                        result_file = signed_file
            
            # Check file size
            if result_file and os.path.exists(result_file):
                file_size = os.path.getsize(result_file)
                if file_size > 50 * 1024 * 1024:  # 50MB
                    self._update_message(chat_id, message_id, f"⚠️ File terlalu besar ({file_size//1024//1024}MB), akan di-split...")
            
            # Update stats
            self.build_stats["success"] += 1
            self.build_stats["pending"] -= 1
            self.build_stats["last_build"] = time.strftime("%Y-%m-%d %H:%M:%S")
            self._save_stats()
            
            # Send result via bot (will be handled by main bot)
            self._update_message(chat_id, message_id, f"📤 Build selesai! Mengirim file...")
            
        except Exception as e:
            self.logger.error(f"Build failed: {str(e)}", exc_info=True)
            
            # Update stats
            self.build_stats["failed"] += 1
            self.build_stats["pending"] -= 1
            self._save_stats()
            
            self._update_message(chat_id, message_id, f"❌ Build gagal: {str(e)}")
            result_file = None
        
        finally:
            # Cleanup build directory
            if build_dir and os.path.exists(build_dir):
                try:
                    shutil.rmtree(build_dir, ignore_errors=True)
                except:
                    pass
        
        # Return result file path to main bot
        return result_file
    
    def _update_message(self, chat_id: int, message_id: int, text: str):
        """Update message in Telegram"""
        try:
            self.bot.edit_message_text(
                chat_id=chat_id,
                message_id=message_id,
                text=text,
                parse_mode="Markdown"
            )
        except Exception as e:
            self.logger.warning(f"Failed to update message: {e}")
    
    def _build_flutter_android(self, project_dir: str, build_id: str, user_id: int) -> Optional[str]:
        """Build Flutter Android APK"""
        try:
            # Check if flutter is installed
            result = subprocess.run(['which', 'flutter'], capture_output=True, text=True)
            if result.returncode != 0:
                raise Exception("Flutter tidak ditemukan di system!")
            
            # Clean and get packages
            subprocess.run(['flutter', 'clean'], cwd=project_dir, capture_output=True, check=False)
            subprocess.run(['flutter', 'pub', 'get'], cwd=project_dir, capture_output=True, check=True, timeout=300)
            
            # Build APK
            result = subprocess.run(
                ['flutter', 'build', 'apk', '--release'],
                cwd=project_dir,
                capture_output=True,
                text=True,
                timeout=900  # 15 minutes
            )
            
            if result.returncode != 0:
                self.logger.error(f"Flutter build failed: {result.stderr}")
                raise Exception(f"Build gagal: {result.stderr[-500:]}")
            
            # Find APK
            apk_path = None
            for root, dirs, files in os.walk(project_dir):
                for file in files:
                    if file.endswith('-release.apk'):
                        apk_path = os.path.join(root, file)
                        break
                if apk_path:
                    break
            
            if not apk_path:
                raise Exception("APK tidak ditemukan setelah build!")
            
            # Copy to output
            from telegram_bot.config import BUILD_OUTPUT_DIR
            output_path = os.path.join(BUILD_OUTPUT_DIR, f"{build_id}.apk")
            shutil.copy2(apk_path, output_path)
            
            return output_path
            
        except subprocess.TimeoutExpired:
            raise Exception("Build timeout setelah 15 menit!")
        except Exception as e:
            self.logger.error(f"Flutter Android build error: {str(e)}", exc_info=True)
            raise
    
    def _build_flutter_web(self, project_dir: str, build_id: str, user_id: int) -> Optional[str]:
        """Build Flutter Web"""
        try:
            # Check flutter
            subprocess.run(['which', 'flutter'], check=True, capture_output=True)
            
            # Enable web
            subprocess.run(['flutter', 'config', '--enable-web'], cwd=project_dir, capture_output=True)
            
            # Clean and get packages
            subprocess.run(['flutter', 'clean'], cwd=project_dir, capture_output=True, check=False)
            subprocess.run(['flutter', 'pub', 'get'], cwd=project_dir, capture_output=True, check=True, timeout=300)
            
            # Build web
            result = subprocess.run(
                ['flutter', 'build', 'web', '--release'],
                cwd=project_dir,
                capture_output=True,
                text=True,
                timeout=600
            )
            
            if result.returncode != 0:
                raise Exception(f"Build gagal: {result.stderr[-500:]}")
            
            # Zip web build
            web_dir = os.path.join(project_dir, 'build', 'web')
            if not os.path.exists(web_dir):
                raise Exception("Web build directory tidak ditemukan!")
            
            from telegram_bot.config import BUILD_OUTPUT_DIR
            output_path = os.path.join(BUILD_OUTPUT_DIR, f"{build_id}.zip")
            
            shutil.make_archive(output_path.replace('.zip', ''), 'zip', web_dir)
            
            return output_path
            
        except Exception as e:
            self.logger.error(f"Flutter Web build error: {str(e)}", exc_info=True)
            raise
    
    def _build_native_android(self, project_dir: str, build_id: str, user_id: int) -> Optional[str]:
        """Build Native Android using Gradle"""
        try:
            # Check if gradlew exists
            gradlew = os.path.join(project_dir, 'gradlew')
            if os.path.exists(gradlew):
                os.chmod(gradlew, 0o755)
                cmd = [gradlew, 'assembleRelease']
            else:
                cmd = ['gradle', 'assembleRelease']
            
            # Run gradle
            result = subprocess.run(
                cmd,
                cwd=project_dir,
                capture_output=True,
                text=True,
                timeout=900
            )
            
            if result.returncode != 0:
                raise Exception(f"Gradle build failed: {result.stderr[-500:]}")
            
            # Find APK
            apk_path = None
            for root, dirs, files in os.walk(project_dir):
                for file in files:
                    if file.endswith('-release.apk') and 'outputs' in root:
                        apk_path = os.path.join(root, file)
                        break
                if apk_path:
                    break
            
            if not apk_path:
                raise Exception("APK tidak ditemukan setelah build!")
            
            # Copy to output
            from telegram_bot.config import BUILD_OUTPUT_DIR
            output_path = os.path.join(BUILD_OUTPUT_DIR, f"{build_id}.apk")
            shutil.copy2(apk_path, output_path)
            
            return output_path
            
        except Exception as e:
            self.logger.error(f"Native Android build error: {str(e)}", exc_info=True)
            raise
    
    def _sign_apk(self, apk_path: str, keystore_path: str, env_file: str) -> Optional[str]:
        """Sign APK with user's keystore"""
        try:
            # Load env
            env_vars = {}
            with open(env_file, 'r') as f:
                for line in f:
                    if '=' in line:
                        k, v = line.strip().split('=', 1)
                        env_vars[k] = v
            
            # Check if apksigner exists
            result = subprocess.run(['which', 'apksigner'], capture_output=True, text=True)
            if result.returncode != 0:
                self.logger.warning("apksigner not found, skipping signing")
                return apk_path
            
            signed_apk = apk_path.replace('.apk', '-signed.apk')
            
            # Build command
            cmd = [
                'apksigner', 'sign',
                '--ks', keystore_path,
                '--ks-pass', f"pass:{env_vars.get('KEYSTORE_PASS', '')}",
                '--ks-key-alias', env_vars.get('KEY_ALIAS', 'my-key'),
                '--key-pass', f"pass:{env_vars.get('KEY_PASS', '')}",
                '--out', signed_apk,
                apk_path
            ]
            
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode == 0 and os.path.exists(signed_apk):
                self.logger.info("APK signed successfully")
                return signed_apk
            else:
                self.logger.warning(f"Signing failed: {result.stderr}")
                return apk_path
                
        except Exception as e:
            self.logger.error(f"Signing error: {str(e)}")
            return apk_path
    
    def get_stats(self) -> Dict[str, Any]:
        """Get build statistics"""
        # Calculate disk usage
        from telegram_bot.config import BUILD_OUTPUT_DIR
        total_size = 0
        if os.path.exists(BUILD_OUTPUT_DIR):
            for root, dirs, files in os.walk(BUILD_OUTPUT_DIR):
                for file in files:
                    file_path = os.path.join(root, file)
                    total_size += os.path.getsize(file_path)
        
        disk_usage = f"{total_size // (1024*1024)} MB" if total_size > 0 else "0 MB"
        
        stats = self.build_stats.copy()
        stats['disk_usage'] = disk_usage
        return stats