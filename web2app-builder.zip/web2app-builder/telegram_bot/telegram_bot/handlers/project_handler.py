import os
import subprocess
import tempfile
import shutil
import zipfile
import time
from typing import Tuple, Optional

class ProjectHandler:
    def __init__(self, bot, logger):
        self.bot = bot
        self.logger = logger
        self.templates_dir = "/tmp/web2app_templates"
        os.makedirs(self.templates_dir, exist_ok=True)
    
    def create_project(self, chat_id: int, user_id: int, project_type: str, project_name: str) -> Tuple[bool, Optional[str]]:
        """Create new Flutter/Android project"""
        try:
            # Create temp directory
            build_id = f"project_{user_id}_{int(time.time())}"
            project_dir = tempfile.mkdtemp(prefix=f"web2app_{build_id}_")
            
            if project_type == "flutter":
                # Check if flutter is installed
                result = subprocess.run(['which', 'flutter'], capture_output=True, text=True)
                if result.returncode != 0:
                    raise Exception("Flutter tidak ditemukan di system!")
                
                # Create Flutter project
                result = subprocess.run(
                    ['flutter', 'create', '--project-name', project_name, project_dir],
                    capture_output=True,
                    text=True,
                    timeout=60
                )
                
                if result.returncode != 0:
                    raise Exception(f"Flutter create failed: {result.stderr}")
                
                # Add telelog integration
                self._add_telelog_to_project(os.path.join(project_dir, project_name))
                
                # Zip project
                zip_path = os.path.join(self.templates_dir, f"{build_id}.zip")
                shutil.make_archive(zip_path.replace('.zip', ''), 'zip', os.path.join(project_dir, project_name))
                
            elif project_type == "native":
                # Create simple Android project structure
                app_dir = os.path.join(project_dir, project_name)
                os.makedirs(os.path.join(app_dir, "app", "src", "main", "java", "com", "example"))
                os.makedirs(os.path.join(app_dir, "app", "src", "main", "res", "layout"))
                
                # Create basic files
                self._create_native_android_project(app_dir, project_name)
                
                # Zip project
                zip_path = os.path.join(self.templates_dir, f"{build_id}.zip")
                shutil.make_archive(zip_path.replace('.zip', ''), 'zip', app_dir)
                
            else:
                raise Exception(f"Tipe project tidak dikenal: {project_type}")
            
            # Cleanup
            shutil.rmtree(project_dir, ignore_errors=True)
            
            return True, zip_path
            
        except Exception as e:
            self.logger.error(f"Project creation error: {str(e)}", exc_info=True)
            return False, str(e)
    
    def _add_telelog_to_project(self, project_path: str):
        """Add telelog package to Flutter project"""
        pubspec_path = os.path.join(project_path, "pubspec.yaml")
        
        if not os.path.exists(pubspec_path):
            return
        
        # Read pubspec
        with open(pubspec_path, 'r') as f:
            content = f.read()
        
        # Add telelog dependency
        if 'telelog:' not in content:
            # Find dependencies section
            if 'dependencies:' in content:
                # Add after flutter sdk
                lines = content.split('\n')
                new_lines = []
                for line in lines:
                    new_lines.append(line)
                    if '  flutter:' in line and 'sdk: flutter' in line:
                        new_lines.append('  telelog: ^0.0.1')
                
                content = '\n'.join(new_lines)
            else:
                content += '\n\ndependencies:\n  telelog: ^0.0.1\n'
        
        # Write back
        with open(pubspec_path, 'w') as f:
            f.write(content)
        
        # Create example usage in main.dart
        main_path = os.path.join(project_path, "lib", "main.dart")
        if os.path.exists(main_path):
            with open(main_path, 'r') as f:
                main_content = f.read()
            
            # Add import if not exists
            if "import 'package:telelog/telelog.dart';" not in main_content:
                main_content = "import 'package:telelog/telelog.dart';\n" + main_content
            
            # Add telelog initialization in main function
            if "void main()" in main_content:
                telelog_code = '''
final telelog = Telelog(
  botToken: 'YOUR_BOT_TOKEN',
  chatId: 'YOUR_CHAT_ID',
);

'''
                main_content = main_content.replace('void main()', telelog_code + 'void main()')
            
            with open(main_path, 'w') as f:
                f.write(main_content)
    
    def _create_native_android_project(self, project_path: str, project_name: str):
        """Create basic native Android project structure"""
        package_name = f"com.example.{project_name.lower()}"
        package_path = package_name.replace('.', '/')
        
        # Create directories
        java_dir = os.path.join(project_path, "app", "src", "main", "java", package_path)
        os.makedirs(java_dir, exist_ok=True)
        
        # Create MainActivity.java
        main_activity = f"""package {package_name};

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {{
    @Override
    protected void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }}
}}
"""
        with open(os.path.join(java_dir, "MainActivity.java"), 'w') as f:
            f.write(main_activity)
        
        # Create activity_main.xml
        layout_dir = os.path.join(project_path, "app", "src", "main", "res", "layout")
        os.makedirs(layout_dir, exist_ok=True)
        
        layout_xml = """<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">
    
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Hello from WEB2APP Builder!"
        android:textSize="24sp"
        android:layout_gravity="center"
        android:layout_marginTop="32dp"/>
        
</LinearLayout>
"""
        with open(os.path.join(layout_dir, "activity_main.xml"), 'w') as f:
            f.write(layout_xml)
        
        # Create AndroidManifest.xml
        manifest_dir = os.path.join(project_path, "app", "src", "main")
        manifest = f"""<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="{package_name}">
    
    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="{project_name}"
        android:theme="@style/Theme.AppCompat.Light">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
    
</manifest>
"""
        with open(os.path.join(manifest_dir, "AndroidManifest.xml"), 'w') as f:
            f.write(manifest)
        
        # Create build.gradle
        build_gradle = """apply plugin: 'com.android.application'

android {
    compileSdk 34
    
    defaultConfig {
        applicationId "{package_name}"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }
    
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.9.0'
}
""".replace("{package_name}", package_name)
        
        with open(os.path.join(project_path, "app", "build.gradle"), 'w') as f:
            f.write(build_gradle)
        
        # Create settings.gradle
        settings = """rootProject.name = "{project_name}"
include ':app'
""".replace("{project_name}", project_name)
        
        with open(os.path.join(project_path, "settings.gradle"), 'w') as f:
            f.write(settings)