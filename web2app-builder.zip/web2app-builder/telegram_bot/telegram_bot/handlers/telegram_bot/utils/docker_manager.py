import subprocess
import os
from typing import Optional, Tuple

class DockerManager:
    def __init__(self, logger):
        self.logger = logger
        self._check_docker()
    
    def _check_docker(self) -> bool:
        """Check if docker is available"""
        try:
            result = subprocess.run(['docker', '--version'], capture_output=True, text=True)
            if result.returncode == 0:
                self.logger.info(f"Docker available: {result.stdout.strip()}")
                return True
            else:
                self.logger.warning("Docker not available, using subprocess fallback")
                return False
        except:
            self.logger.warning("Docker not available, using subprocess fallback")
            return False
    
    def ensure_image(self, image_name: str, dockerfile_path: str) -> bool:
        """Ensure Docker image exists, build if not"""
        try:
            # Check if image exists
            result = subprocess.run(
                ['docker', 'image', 'inspect', image_name],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                return True
            
            # Build image
            self.logger.info(f"Building Docker image: {image_name}")
            result = subprocess.run(
                ['docker', 'build', '-t', image_name, '-f', dockerfile_path, '.'],
                cwd=os.path.dirname(dockerfile_path),
                capture_output=True,
                text=True,
                timeout=300
            )
            
            if result.returncode == 0:
                self.logger.info(f"Image {image_name} built successfully")
                return True
            else:
                self.logger.error(f"Failed to build image: {result.stderr}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error ensuring Docker image: {e}")
            return False
    
    def run_container(self, image_name: str, command: str, volumes: dict, workdir: str = None) -> Tuple[bool, str]:
        """Run command in Docker container"""
        try:
            # Build volume mounts
            volume_args = []
            for host_path, container_path in volumes.items():
                volume_args.extend(['-v', f"{host_path}:{container_path}"])
            
            # Build command
            cmd = ['docker', 'run', '--rm']
            if workdir:
                cmd.extend(['-w', workdir])
            cmd.extend(volume_args)
            cmd.append(image_name)
            cmd.extend(command.split())
            
            self.logger.info(f"Running Docker command: {' '.join(cmd)}")
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=1800
            )
            
            if result.returncode == 0:
                return True, result.stdout
            else:
                return False, result.stderr
                
        except subprocess.TimeoutExpired:
            return False, "Container execution timeout after 30 minutes"
        except Exception as e:
            return False, str(e)