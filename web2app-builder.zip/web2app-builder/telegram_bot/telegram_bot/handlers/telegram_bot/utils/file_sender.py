import os
import requests
import math
from typing import List, Optional

def send_file_to_telegram(bot_token: str, chat_id: int, file_path: str, caption: str = "") -> bool:
    """Send file directly to Telegram (bypass python-telegram-bot for large files)"""
    url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
    
    try:
        # Check file size
        file_size = os.path.getsize(file_path)
        max_size = 50 * 1024 * 1024  # 50MB
        
        if file_size > max_size:
            # Split file
            parts = split_large_file(file_path, 50)
            success = True
            
            for i, part in enumerate(parts):
                part_caption = f"{caption} (part {i+1}/{len(parts)})"
                with open(part, 'rb') as f:
                    files = {'document': f}
                    data = {'chat_id': chat_id, 'caption': part_caption}
                    response = requests.post(url, files=files, data=data, timeout=60)
                    
                    if response.status_code != 200:
                        success = False
                        print(f"Failed to send part {i+1}: {response.text}")
                
                # Cleanup part
                try:
                    os.remove(part)
                except:
                    pass
            
            return success
        else:
            with open(file_path, 'rb') as f:
                files = {'document': f}
                data = {'chat_id': chat_id, 'caption': caption}
                response = requests.post(url, files=files, data=data, timeout=60)
                return response.status_code == 200
                
    except Exception as e:
        print(f"Error sending file: {e}")
        return False

def split_large_file(file_path: str, max_size_mb: int = 50) -> List[str]:
    """Split large file into smaller chunks"""
    max_size_bytes = max_size_mb * 1024 * 1024
    file_size = os.path.getsize(file_path)
    
    if file_size <= max_size_bytes:
        return [file_path]
    
    # Split file into parts
    num_parts = math.ceil(file_size / max_size_bytes)
    
    part_files = []
    with open(file_path, 'rb') as f:
        for i in range(num_parts):
            part_path = f"{file_path}.part{i+1}"
            with open(part_path, 'wb') as part_f:
                part_f.write(f.read(max_size_bytes))
            part_files.append(part_path)
    
    return part_files

def merge_file_parts(part_files: List[str], output_path: str) -> bool:
    """Merge split file parts back"""
    try:
        with open(output_path, 'wb') as outfile:
            for part in sorted(part_files):
                with open(part, 'rb') as infile:
                    outfile.write(infile.read())
        return True
    except Exception as e:
        print(f"Error merging files: {e}")
        return False