import os
import psutil
import time
from typing import List

class AdminHandler:
    def __init__(self, bot, logger, admin_ids: List[int]):
        self.bot = bot
        self.logger = logger
        self.admin_ids = admin_ids
    
    def is_admin(self, user_id: int) -> bool:
        """Check if user is admin"""
        return user_id in self.admin_ids
    
    def handle_stats(self, message):
        """Handle /stats command"""
        if not self.is_admin(message.from_user.id):
            self.bot.reply_to(message, "❌ Lu bukan admin bos!")
            return
        
        # System stats
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Process stats
        process = psutil.Process()
        with process.oneshot():
            create_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(process.create_time()))
            mem_info = process.memory_info()
        
        stats_text = f"""
📊 *SYSTEM STATISTICS*

🖥️ *CPU:* {cpu_percent}%
💾 *RAM:* {memory.used // (1024**2)}MB / {memory.total // (1024**2)}MB ({memory.percent}%)
💿 *Disk:* {disk.used // (1024**3)}GB / {disk.total // (1024**3)}GB

🤖 *BOT PROCESS:*
• Uptime: {create_time}
• Memory: {mem_info.rss // (1024**2)}MB
• Threads: {process.num_threads()}

👥 *Active Users:* {self._count_active_users()}
📁 *Builds Dir:* {self._get_dir_size('/tmp/web2app_builds')} MB
        """
        
        self.bot.reply_to(message, stats_text, parse_mode="Markdown")
    
    def handle_logs(self, message, lines: int = 50):
        """Handle /logs command"""
        if not self.is_admin(message.from_user.id):
            self.bot.reply_to(message, "❌ Lu bukan admin bos!")
            return
        
        log_file = "/app/logs/web2app_bot.log"
        if not os.path.exists(log_file):
            self.bot.reply_to(message, "❌ Log file tidak ditemukan!")
            return
        
        try:
            with open(log_file, 'r') as f:
                logs = f.readlines()[-lines:]
            
            log_text = "```\n" + ''.join(logs) + "\n```"
            
            if len(log_text) > 4000:
                # Send as file
                with open("/tmp/last_logs.txt", 'w') as f:
                    f.write(''.join(logs))
                with open("/tmp/last_logs.txt", 'rb') as f:
                    self.bot.send_document(message.chat.id, f, caption=f"Last {lines} lines of log")
                os.remove("/tmp/last_logs.txt")
            else:
                self.bot.reply_to(message, log_text, parse_mode="Markdown")
                
        except Exception as e:
            self.bot.reply_to(message, f"❌ Error reading logs: {str(e)}")
    
    def handle_restart(self, message):
        """Handle /restart command"""
        if not self.is_admin(message.from_user.id):
            self.bot.reply_to(message, "❌ Lu bukan admin bos!")
            return
        
        self.bot.reply_to(message, "♻️ Restarting bot...")
        self.logger.warning(f"Bot restart initiated by admin {message.from_user.id}")
        
        # Restart bot (will be handled by supervisor/docker)
        import sys
        os.execv(sys.executable, ['python'] + sys.argv)
    
    def _count_active_users(self) -> int:
        """Count active users from build directories"""
        try:
            users = set()
            builds_dir = "/tmp/web2app_builds"
            if os.path.exists(builds_dir):
                for file in os.listdir(builds_dir):
                    if file.startswith('build_'):
                        parts = file.split('_')
                        if len(parts) > 1 and parts[1].isdigit():
                            users.add(parts[1])
            return len(users)
        except:
            return 0
    
    def _get_dir_size(self, path: str) -> str:
        """Get directory size in MB"""
        try:
            if not os.path.exists(path):
                return "0"
            
            total = 0
            for root, dirs, files in os.walk(path):
                for file in files:
                    file_path = os.path.join(root, file)
                    total += os.path.getsize(file_path)
            
            return f"{total // (1024*1024)}"
        except:
            return "0"