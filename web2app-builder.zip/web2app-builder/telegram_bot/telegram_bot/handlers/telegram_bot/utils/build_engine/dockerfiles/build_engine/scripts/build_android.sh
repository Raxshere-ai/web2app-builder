#!/bin/bash
# build_android.sh - Build Android APK from Flutter project

set -e

PROJECT_DIR=$1
BUILD_TYPE=${2:-release}

echo "🔧 Starting Android build at $(date)"
echo "Project: $PROJECT_DIR"
echo "Type: $BUILD_TYPE"

cd "$PROJECT_DIR"

# Check if Flutter project
if [ -f "pubspec.yaml" ]; then
    echo "📦 Flutter project detected"
    
    # Clean
    echo "🧹 Cleaning..."
    flutter clean
    
    # Get packages
    echo "📦 Getting packages..."
    flutter pub get
    
    # Build
    echo "🔨 Building APK..."
    if [ "$BUILD_TYPE" == "release" ]; then
        flutter build apk --release
    else
        flutter build apk --debug
    fi
    
    # Find APK
    APK_PATH=$(find build -name "*.apk" | head -1)
    
# Check if Android native project
elif [ -f "gradlew" ] || [ -f "build.gradle" ]; then
    echo "📦 Android native project detected"
    
    # Make gradlew executable
    if [ -f "gradlew" ]; then
        chmod +x gradlew
        echo "🔨 Running ./gradlew assembleRelease..."
        ./gradlew assembleRelease
    else
        echo "🔨 Running gradle assembleRelease..."
        gradle assembleRelease
    fi
    
    # Find APK
    APK_PATH=$(find app/build -name "*.apk" | head -1)
    
else
    echo "❌ Not a valid Flutter or Android project!"
    exit 1
fi

# Check result
if [ -z "$APK_PATH" ]; then
    echo "❌ APK not found!"
    exit 1
fi

echo "✅ Build successful!"
echo "APK: $APK_PATH"
echo "Size: $(du -h "$APK_PATH" | cut -f1)"

# Output for other scripts
echo "APK_PATH=$APK_PATH"