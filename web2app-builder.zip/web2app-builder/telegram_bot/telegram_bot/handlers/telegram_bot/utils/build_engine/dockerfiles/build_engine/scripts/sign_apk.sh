#!/bin/bash
# sign_apk.sh - Sign APK with keystore

APK_PATH=$1
KEYSTORE_PATH=$2
KEYSTORE_PASS=$3
KEY_ALIAS=$4
KEY_PASS=$5

SIGNED_APK="${APK_PATH%.*}-signed.apk"

apksigner sign \
    --ks $KEYSTORE_PATH \
    --ks-pass pass:$KEYSTORE_PASS \
    --ks-key-alias $KEY_ALIAS \
    --key-pass pass:$KEY_PASS \
    --out $SIGNED_APK \
    $APK_PATH

if [ $? -eq 0 ]; then
    echo "✅ APK signed successfully: $SIGNED_APK"
    echo "SIGNED_APK=$SIGNED_APK"
else
    echo "❌ Signing failed"
    exit 1
fi