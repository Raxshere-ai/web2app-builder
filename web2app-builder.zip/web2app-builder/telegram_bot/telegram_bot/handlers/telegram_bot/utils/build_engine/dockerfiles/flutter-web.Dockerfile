FROM ubuntu:22.04

LABEL maintainer="DEWAGPT"
LABEL description="Flutter Web Builder"

# Install dependencies
RUN apt-get update && apt-get install -y \
    curl \
    git \
    unzip \
    xz-utils \
    zip \
    wget \
    python3 \
    python3-pip \
    nodejs \
    npm \
    nginx \
    && rm -rf /var/lib/apt/lists/*

# Install Flutter
ENV FLUTTER_HOME=/opt/flutter
ENV PATH=$PATH:$FLUTTER_HOME/bin

RUN git clone https://github.com/flutter/flutter.git -b stable $FLUTTER_HOME && \
    flutter doctor

# Install web dependencies
RUN flutter config --enable-web

WORKDIR /app

EXPOSE 5000

CMD ["flutter", "--version"]