#!/usr/bin/env python3
"""
WEB2APP BUILDER BOT - MODE DAJAL
Fully fixed and production ready
"""

import telebot
import os
import sys
import logging
from typing import Optional

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from telegram_bot.config import BOT_TOKEN, ADMIN_IDS, LOG_DIR
from telegram_bot.handlers.build_handler import BuildHandler
from telegram_bot.handlers.project_handler import ProjectHandler
from telegram_bot.handlers.admin_handler import AdminHandler
from telegram_bot.utils.logger import setup_logger
from telegram_bot.utils.file_sender import send_file_to_telegram

# Setup logging
logger = setup_logger("web2app_bot", LOG_DIR)

# Initialize bot
bot = telebot.TeleBot(BOT_TOKEN)

# Initialize handlers
build_handler = BuildHandler(bot, logger)
project_handler = ProjectHandler(bot, logger)
admin_handler = AdminHandler(bot, logger, ADMIN_IDS)

@bot.message_handler(commands=['start'])
def start_cmd(message):
    """Welcome message"""
    welcome = """
🔥 *WEB2APP BUILDER BOT v2.0 FIXED* 🔥
Mode: DEWAGPT (Full Access)

🚀 *FITUR LENGKAP:*
• Build Flutter Android (APK/AAB)
• Build Flutter Web
• Build Native Android (Java)
• Auto APK Signing
• Git Integration

📋 *PERINTAH:*

/build_android [repo_url] - Build Android APK
/build_web [repo_url] - Build Flutter Web
/build_native [repo_url] - Build Native Android
/new_project [type] [name] - Buat project baru
/set_keystore - Upload keystore untuk signing
/stats - Lihat statistik (admin only)

*CONTOH:*
/build_android https://github.com/user/flutter_app.git
/new_project flutter myapp

_Mau bikin apa hari ini?_
    """
    bot.reply_to(message, welcome, parse_mode="Markdown")

@bot.message_handler(commands=['build_android', 'build_web', 'build_native'])
def handle_build(message):
    """Handle all build commands"""
    try:
        # Parse command
        parts = message.text.split()
        if len(parts) < 2:
            bot.reply_to(message, "Format: /build_android [repo_url]\nContoh: /build_android https://github.com/user/app.git")
            return
        
        build_type = parts[0].replace("/build_", "")
        repo_url = parts[1]
        
        # Validate URL
        if not repo_url.startswith(('http://', 'https://', 'git@')):
            bot.reply_to(message, "❌ URL repository tidak valid! Gunakan HTTP/HTTPS atau Git URL.")
            return
        
        # Send initial status
        status_msg = bot.reply_to(
            message, 
            f"⚙️ *Memulai build {build_type}...*\nRepo: `{repo_url}`\n\nTunggu ya, ini bisa 5-15 menit!",
            parse_mode="Markdown"
        )
        
        # Start build
        success, result = build_handler.start_build(
            chat_id=message.chat.id,
            user_id=message.from_user.id,
            build_type=build_type,
            repo_url=repo_url,
            message_id=status_msg.message_id
        )
        
        if success:
            # Send result file
            if result and os.path.exists(result):
                with open(result, 'rb') as f:
                    bot.send_document(
                        message.chat.id,
                        f,
                        caption=f"✅ *Build {build_type} berhasil!*\nRepo: {repo_url}",
                        parse_mode="Markdown"
                    )
                # Cleanup
                try:
                    os.remove(result)
                except:
                    pass
            else:
                bot.reply_to(message, "✅ Build selesai tapi file tidak ditemukan.")
        else:
            bot.reply_to(message, f"❌ Build gagal: {result}")
        
        # Delete status message
        try:
            bot.delete_message(message.chat.id, status_msg.message_id)
        except:
            pass
        
    except Exception as e:
        logger.error(f"Build error: {str(e)}", exc_info=True)
        bot.reply_to(message, f"❌ Error: {str(e)}")

@bot.message_handler(commands=['new_project'])
def create_project(message):
    """Create new Flutter/Android project"""
    try:
        parts = message.text.split()
        if len(parts) < 3:
            bot.reply_to(message, "Format: /new_project [type] [name]\nType: flutter, native\nContoh: /new_project flutter myapp")
            return
        
        project_type = parts[1].lower()
        project_name = parts[2]
        
        # Validate project name
        if not project_name.isidentifier():
            bot.reply_to(message, "❌ Nama project hanya boleh huruf, angka, dan underscore!")
            return
        
        if project_type not in ['flutter', 'native']:
            bot.reply_to(message, "❌ Tipe project harus 'flutter' atau 'native'")
            return
        
        # Create project
        success, result = project_handler.create_project(
            chat_id=message.chat.id,
            user_id=message.from_user.id,
            project_type=project_type,
            project_name=project_name
        )
        
        if success and result and os.path.exists(result):
            with open(result, 'rb') as f:
                bot.send_document(
                    message.chat.id,
                    f,
                    caption=f"✅ *Project {project_name} created!*\n\nExtract dan jalankan:\n```\ncd {project_name}\nflutter pub get\nflutter run\n```",
                    parse_mode="Markdown"
                )
            # Cleanup
            try:
                os.remove(result)
            except:
                pass
        else:
            bot.reply_to(message, f"❌ Gagal membuat project: {result}")
        
    except Exception as e:
        logger.error(f"Project creation error: {str(e)}", exc_info=True)
        bot.reply_to(message, f"❌ Error: {str(e)}")

@bot.message_handler(commands=['set_keystore'])
def handle_keystore(message):
    """Handle keystore upload"""
    msg = bot.reply_to(
        message, 
        "📤 Kirim file keystore lu (format .jks atau .keystore)\n\nPastikan filenya adalah keystore valid untuk signing APK."
    )
    bot.register_next_step_handler(msg, process_keystore_upload)

def process_keystore_upload(message):
    """Process uploaded keystore file"""
    try:
        if not message.document:
            bot.reply_to(message, "❌ Kirim file keystore, bukan teks!")
            return
        
        # Check file extension
        file_name = message.document.file_name
        if not (file_name.endswith('.jks') or file_name.endswith('.keystore')):
            bot.reply_to(message, "❌ File harus .jks atau .keystore")
            return
        
        # Download file
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        
        # Save keystore
        from telegram_bot.config import KEYSTORE_DIR
        keystore_path = os.path.join(KEYSTORE_DIR, f"user_{message.from_user.id}.jks")
        
        with open(keystore_path, 'wb') as f:
            f.write(downloaded_file)
        
        bot.reply_to(
            message, 
            "✅ Keystore berhasil disimpan!\n\nSekarang set passwordnya dengan:\n`/setenv KEYSTORE_PASS password123`\n`/setenv KEY_ALIAS my-alias`\n`/setenv KEY_PASS password123`",
            parse_mode="Markdown"
        )
        
    except Exception as e:
        logger.error(f"Keystore upload error: {str(e)}", exc_info=True)
        bot.reply_to(message, f"❌ Error: {str(e)}")

@bot.message_handler(commands=['setenv'])
def set_environment(message):
    """Set environment variables for user"""
    try:
        parts = message.text.split()
        if len(parts) < 3:
            bot.reply_to(message, "Format: /setenv [KEY] [VALUE]\nContoh: /setenv KEYSTORE_PASS rahasia123")
            return
        
        key = parts[1].upper()
        value = ' '.join(parts[2:])
        user_id = message.from_user.id
        
        # Save to user's env file
        from telegram_bot.config import ENV_DIR
        env_file = os.path.join(ENV_DIR, f"user_{user_id}.env")
        
        # Read existing env
        env_vars = {}
        if os.path.exists(env_file):
            with open(env_file, 'r') as f:
                for line in f:
                    if '=' in line:
                        k, v = line.strip().split('=', 1)
                        env_vars[k] = v
        
        # Update
        env_vars[key] = value
        
        # Write back
        with open(env_file, 'w') as f:
            for k, v in env_vars.items():
                f.write(f"{k}={v}\n")
        
        bot.reply_to(message, f"✅ Environment {key} berhasil disimpan!")
        
    except Exception as e:
        logger.error(f"Setenv error: {str(e)}", exc_info=True)
        bot.reply_to(message, f"❌ Error: {str(e)}")

@bot.message_handler(commands=['stats'])
def show_stats(message):
    """Show build statistics (admin only)"""
    if message.from_user.id not in ADMIN_IDS:
        bot.reply_to(message, "❌ Lu bukan admin bos!")
        return
    
    stats = build_handler.get_stats()
    
    stats_text = f"""
📊 *BUILD STATISTICS*

Total Builds: {stats['total_builds']}
✅ Success: {stats['success']}
❌ Failed: {stats['failed']}
⏳ Pending: {stats['pending']}

*Per Platform:*
📱 Android: {stats['android']}
🌐 Web: {stats['web']}
☕ Native: {stats['native']}

💾 Disk Usage: {stats['disk_usage']}
🕐 Last Build: {stats['last_build']}
    """
    bot.reply_to(message, stats_text, parse_mode="Markdown")

@bot.message_handler(func=lambda m: True)
def handle_all(message):
    """Handle all other messages"""
    text = message.text.lower()
    
    keywords = {
        'bikin apk': 'Gunakan /build_android [repo_url]',
        'build apk': 'Gunakan /build_android [repo_url]',
        'buat aplikasi': 'Gunakan /new_project flutter namaproject',
        'flutter': 'Cek /build_android atau /new_project flutter',
        'error': 'Coba /start dulu atau laporkan ke admin',
        'help': 'Ketik /start untuk bantuan'
    }
    
    for key, response in keywords.items():
        if key in text:
            bot.reply_to(message, response)
            return

if __name__ == "__main__":
    logger.info("🔥 WEB2APP BUILDER BOT STARTED - MODE DAJAL")
    print("✅ BOT RUNNING... Press Ctrl+C to stop")
    
    try:
        bot.infinity_polling(timeout=60, long_polling_timeout=60)
    except KeyboardInterrupt:
        logger.info("Bot stopped by user")
        print("\n❌ Bot stopped")
    except Exception as e:
        logger.error(f"Bot crashed: {str(e)}", exc_info=True)
        print(f"❌ Bot crashed: {e}")