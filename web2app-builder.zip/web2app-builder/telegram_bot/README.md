# WEB2APP BUILDER BOT - MODE DAJAL 🔥

Telegram Bot untuk build Flutter & Android apps secara otomatis.

## ✨ FITUR LENGKAP

- ✅ Build Flutter Android (APK/AAB)
- ✅ Build Flutter Web
- ✅ Build Native Android (Java)
- ✅ Auto APK Signing dengan keystore
- ✅ Git integration
- ✅ Project templates
- ✅ Admin dashboard
- ✅ Real-time build status

## 📋 PREREQUISITES

- Python 3.8+
- Flutter SDK
- Android SDK
- Git
- Telegram Bot Token (dari @BotFather)

## 🚀 INSTALLASI CEPAT

```bash
# 1. Clone repository
git clone https://github.com/yourusername/web2app-builder.git
cd web2app-builder

# 2. Install dependencies
pip install -r telegram_bot/requirements.txt

# 3. Edit .env file
nano .env
# Isi BOT_TOKEN dengan token dari @BotFather

# 4. Jalankan bot
python -m telegram_bot.bot