// WEB2APP Builder Dashboard - JavaScript Controller

const API_BASE = '/api';
let builds = [];

// Load recent builds on page load
document.addEventListener('DOMContentLoaded', function() {
    loadRecentBuilds();
    checkBuilderStatus();
    
    // Handle form submission
    document.getElementById('buildForm').addEventListener('submit', function(e) {
        e.preventDefault();
        startNewBuild();
    });
    
    // Show keystore section for release builds
    document.getElementById('buildType').addEventListener('change', function(e) {
        const section = document.getElementById('keystoreSection');
        section.style.display = e.target.value === 'release' ? 'block' : 'none';
    });
});

// Load recent builds from API
async function loadRecentBuilds() {
    try {
        const response = await fetch(`${API_BASE}/builds/recent`);
        const data = await response.json();
        
        const container = document.getElementById('recentBuilds');
        
        if (data.builds && data.builds.length > 0) {
            builds = data.builds;
            let html = '<ul class="list-group">';
            
            data.builds.forEach(build => {
                const statusClass = build.status === 'success' ? 'success' : 
                                   build.status === 'failed' ? 'danger' : 'warning';
                
                html += `
                    <li class="list-group-item list-group-item-${statusClass}">
                        <div class="d-flex justify-content-between">
                            <span>${build.name}</span>
                            <span class="badge bg-${statusClass}">${build.status}</span>
                        </div>
                        <small>${build.time}</small>
                    </li>
                `;
            });
            
            html += '</ul>';
            container.innerHTML = html;
            document.getElementById('buildCount').innerText = `Builds: ${data.builds.length}`;
        } else {
            container.innerHTML = '<p class="text-muted">No builds yet</p>';
        }
    } catch (error) {
        console.error('Failed to load builds:', error);
        document.getElementById('recentBuilds').innerHTML = 
            '<p class="text-danger">Failed to load builds</p>';
    }
}

// Start new build
async function startNewBuild() {
    const projectType = document.getElementById('projectType').value;
    const repoUrl = document.getElementById('repoUrl').value;
    const buildType = document.getElementById('buildType').value;
    
    if (!repoUrl) {
        alert('Repository URL wajib diisi!');
        return;
    }
    
    // Show loading
    const submitBtn = document.querySelector('#buildForm button[type="submit"]');
    const originalText = submitBtn.innerText;
    submitBtn.innerText = '⏳ Processing...';
    submitBtn.disabled = true;
    
    try {
        const formData = new FormData();
        formData.append('type', projectType);
        formData.append('repo', repoUrl);
        formData.append('buildType', buildType);
        
        // Add keystore if provided
        const keystore = document.getElementById('keystore').files[0];
        if (keystore) {
            formData.append('keystore', keystore);
        }
        
        const response = await fetch(`${API_BASE}/build/start`, {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`✅ Build started! Build ID: ${result.buildId}`);
            loadRecentBuilds();
            
            // Add to active builds
            addActiveBuild(result.buildId, projectType, repoUrl);
        } else {
            alert(`❌ Error: ${result.error}`);
        }
        
    } catch (error) {
        alert(`❌ Failed to start build: ${error.message}`);
    } finally {
        submitBtn.innerText = originalText;
        submitBtn.disabled = false;
    }
}

// Add build to active list
function addActiveBuild(buildId, type, repo) {
    const container = document.getElementById('activeBuilds');
    
    if (container.innerHTML.includes('No active builds')) {
        container.innerHTML = '';
    }
    
    const buildEl = document.createElement('div');
    buildEl.className = 'alert alert-info mb-2';
    buildEl.id = `build-${buildId}`;
    buildEl.innerHTML = `
        <div class="d-flex justify-content-between">
            <span><strong>${type}</strong> - ${repo.split('/').pop()}</span>
            <span class="badge bg-warning">Building...</span>
        </div>
        <div class="progress mt-2" style="height: 5px;">
            <div class="progress-bar progress-bar-striped progress-bar-animated" 
                 style="width: 100%"></div>
        </div>
        <small class="text-muted">Build ID: ${buildId}</small>
    `;
    
    container.appendChild(buildEl);
    
    // Simulate completion after 30 seconds
    setTimeout(() => {
        const build = document.getElementById(`build-${buildId}`);
        if (build) {
            build.remove();
        }
        if (container.children.length === 0) {
            container.innerHTML = '<p class="text-muted">No active builds</p>';
        }
        loadRecentBuilds();
    }, 30000);
}

// Check builder status
async function checkBuilderStatus() {
    try {
        const response = await fetch(`${API_BASE}/status`);
        const data = await response.json();
        
        const statusEl = document.getElementById('status');
        if (data.online) {
            statusEl.innerHTML = 'Status: <span class="badge bg-success">Online</span>';
        } else {
            statusEl.innerHTML = 'Status: <span class="badge bg-danger">Offline</span>';
        }
    } catch (error) {
        console.error('Status check failed:', error);
    }
}

// Create template project
async function createTemplate() {
    const type = prompt('Enter project type (flutter/native_android/web):', 'flutter');
    if (!type) return;
    
    const name = prompt('Enter project name:', 'myapp');
    if (!name) return;
    
    try {
        const response = await fetch(`${API_BASE}/template/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type, name })
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert(`✅ Template created! Download: ${result.downloadUrl}`);
        } else {
            alert(`❌ Error: ${result.error}`);
        }
    } catch (error) {
        alert(`❌ Failed: ${error.message}`);
    }
}

// Clear build cache
async function clearCache() {
    if (!confirm('Yakin mau clear semua build cache?')) return;
    
    try {
        const response = await fetch(`${API_BASE}/cache/clear`, {
            method: 'POST'
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert('✅ Cache cleared!');
        } else {
            alert(`❌ Error: ${result.error}`);
        }
    } catch (error) {
        alert(`❌ Failed: ${error.message}`);
    }
}

// Auto-refresh every 30 seconds
setInterval(loadRecentBuilds, 30000);
setInterval(checkBuilderStatus, 10000);