package com.web2app.builder;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * GradleBuilder - Build Native Android projects via Java
 * Support: Java/Kotlin Android apps
 */
public class GradleBuilder {
    
    private String projectPath;
    private String outputPath;
    private ProcessBuilder processBuilder;
    
    public GradleBuilder(String projectPath) {
        this.projectPath = projectPath;
        this.processBuilder = new ProcessBuilder();
        this.processBuilder.directory(new File(projectPath));
        this.processBuilder.redirectErrorStream(true);
    }
    
    /**
     * Build APK using Gradle wrapper
     */
    public BuildResult buildApk(String task, long timeoutSeconds) {
        BuildResult result = new BuildResult();
        
        try {
            // Check if gradlew exists
            File gradlew = new File(projectPath, "gradlew");
            if (!gradlew.exists()) {
                result.success = false;
                result.error = "gradlew not found. Not a valid Android project?";
                return result;
            }
            
            // Make executable
            gradlew.setExecutable(true);
            
            // Build command
            List<String> command = new ArrayList<>();
            command.add("./gradlew");
            command.add(task);
            
            // Add optional args
            command.add("--no-daemon");
            command.add("--stacktrace");
            
            processBuilder.command(command);
            
            // Start process
            Process process = processBuilder.start();
            
            // Read output
            StringBuilder output = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                    System.out.println(line);
                }
            }
            
            // Wait for completion with timeout
            boolean completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
            
            if (!completed) {
                process.destroyForcibly();
                result.success = false;
                result.error = "Build timed out after " + timeoutSeconds + " seconds";
                return result;
            }
            
            int exitCode = process.exitValue();
            result.success = exitCode == 0;
            
            if (result.success) {
                // Find generated APK
                result.apkPath = findApk();
                result.output = output.toString();
            } else {
                result.error = "Build failed with exit code: " + exitCode;
                result.output = output.toString();
            }
            
        } catch (Exception e) {
            result.success = false;
            result.error = e.getMessage();
            e.printStackTrace();
        }
        
        return result;
    }
    
    /**
     * Find generated APK file
     */
    private String findApk() {
        try {
            Path start = Paths.get(projectPath, "app", "build", "outputs");
            return Files.walk(start)
                .filter(p -> p.toString().endsWith(".apk"))
                .map(p -> p.toString())
                .findFirst()
                .orElse(null);
        } catch (IOException e) {
            return null;
        }
    }
    
    /**
     * Build result class
     */
    public static class BuildResult {
        public boolean success;
        public String apkPath;
        public String output;
        public String error;
        
        public BuildResult() {
            this.success = false;
            this.apkPath = null;
            this.output = "";
            this.error = "";
        }
        
        @Override
        public String toString() {
            return "BuildResult{" +
                "success=" + success +
                ", apkPath='" + apkPath + '\'' +
                ", error='" + error + '\'' +
                '}';
        }
    }
    
    /**
     * Main method for command-line usage
     */
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java GradleBuilder <project_path> <task>");
            System.out.println("Example: java GradleBuilder /path/to/project assembleRelease");
            System.exit(1);
        }
        
        String projectPath = args[0];
        String task = args[1];
        
        GradleBuilder builder = new GradleBuilder(projectPath);
        BuildResult result = builder.buildApk(task, 1800);
        
        if (result.success) {
            System.out.println("✅ Build successful!");
            System.out.println("APK: " + result.apkPath);
            System.exit(0);
        } else {
            System.out.println("❌ Build failed: " + result.error);
            System.out.println("\n--- Output ---");
            System.out.println(result.output);
            System.exit(1);
        }
    }
}